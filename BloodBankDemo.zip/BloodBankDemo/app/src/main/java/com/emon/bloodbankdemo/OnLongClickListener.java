package com.emon.bloodbankdemo;

import android.view.View;

public interface OnLongClickListener {
    void onLongClick(View view, int position);
}
